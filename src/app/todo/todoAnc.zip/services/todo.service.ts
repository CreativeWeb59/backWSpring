import { Injectable } from '@angular/core';
import TodoModel from '../models/TodoModel';

@Injectable({
  providedIn: 'root'
})
export class TodoService {

  private _todos: TodoModel[] = [
    new TodoModel("prendre son petit dej"),
    new TodoModel("prendre le métro"),
    new TodoModel("donner formation"),
  ]
  constructor() { }

  get todos(): TodoModel[]{
    return this._todos;
  }

}
