import { Component, Input, Output, EventEmitter } from '@angular/core';
import TodoModel from '../../modeles/TodoModel';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent {

  constructor() {
  }

  @Input()
  datas: TodoModel[] = [new TodoModel('')]


  @Output()
  newDone: EventEmitter<number> = new EventEmitter()

  changeChecked(id: number) {
    this.newDone.emit(id)
  }

  btnDelete: string = "Delete"
  btnStyle:{} = {
    "background-color": "red",
    "color": "white"
  };

  delete = (id: number):void => {
    console.log(id)
  }

}
