import { Component, Output, Input, EventEmitter } from '@angular/core';
import { TodoService } from '../../services/todo.service';

@Component({
  selector: 'app-supr-todo',
  templateUrl: './supr-todo.component.html',
  styleUrls: ['./supr-todo.component.css']
})
export class SuprTodoComponent {
  @Input()
  id!: number;

  @Output()
  recupId: EventEmitter<number> = new EventEmitter()
  
  constructor(private service:TodoService){
  }

  envoiId(e: number){
      this.recupId.emit(e)
      this.service.removeTask(e);
    }
}
