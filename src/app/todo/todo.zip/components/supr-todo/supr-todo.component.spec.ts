import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuprTodoComponent } from './supr-todo.component';

describe('SuprTodoComponent', () => {
  let component: SuprTodoComponent;
  let fixture: ComponentFixture<SuprTodoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SuprTodoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SuprTodoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
