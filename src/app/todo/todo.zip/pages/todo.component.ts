import { Component, EventEmitter, OnInit } from '@angular/core';
import { TodoService } from '../services/todo.service';
import TodoModel from '../modeles/TodoModel';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit{
  
  todos: TodoModel[] = [];
  placeholder: string = "placeholder"

  constructor(private service:TodoService){

  }

  ngOnInit(): void {
      this.getTodos();
  }

  getTodos = (): void => {
    this.todos = this.service.todos
  }

  addTodo = (e: string) => {
    // console.log(e)
  this.service.addTodo(e)
  }

  ChangeDone = (e: number) => {
   this.service.changeDone(e)
  }

}
