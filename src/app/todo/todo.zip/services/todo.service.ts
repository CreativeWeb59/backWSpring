import { Injectable } from '@angular/core';
import TodoModel from '../modeles/TodoModel';


@Injectable({
  providedIn: 'root'
})
export class TodoService {

  private _todos: TodoModel[] = [
    new TodoModel("prendre son petit dej"),
    new TodoModel("prendre le métro"),
    new TodoModel("donner formation"),
  ]
  constructor() { }

  get todos(): TodoModel[] {
    return this._todos;
  }

  addTodo(task: string) {
    this._todos.push(new TodoModel(task));
  }

  changeDone(id: number) {
    const todo: TodoModel | undefined = this._todos.find(item => item.id == id)
    if (todo) {
      todo.done = !todo.done
    }
  }

  removeTask(id: number) {
    let indexASupprimer = -1;
    this._todos.forEach(function(element, index) {
      if(element.id == id){
        indexASupprimer = index;
      }
    });

    if(indexASupprimer != -1){
      this._todos.slice(indexASupprimer, 1);
      console.log("Suppression de la ligne " + indexASupprimer)
    }
    // met a jour la liste :
    this.todos;
  }
}
