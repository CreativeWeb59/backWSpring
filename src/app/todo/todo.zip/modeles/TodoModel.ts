export default class TodoModel {
    // [x: string]: any;
    
    private _id: number;
    private _task: string;
    private _done: boolean = false;
    private static _count: number = 1;

    constructor(task: string) {
      this._task = task
      this._id = TodoModel._count
      TodoModel._count++;
    }
    get id(): number {
      return this._id;
    }
    get task(): string {
      return this._task;
    }
    get done(): boolean {
      return this._done;
    }
    static get count(): number {
      return this._count;
    }
    set done(done:boolean){
      this._done = done;
    }
}